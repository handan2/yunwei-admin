package com.sss.yunweiadmin.model.excel;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import com.alibaba.excel.annotation.write.style.ColumnWidth;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class AsSecurityProductExcel {
    //AsDeviceCommon
    @ExcelProperty("设备编号")
    private String no;
    @ExcelProperty("设备类别")
    private String typeName;
    @ExcelProperty("设备名称")
    @ColumnWidth(20)
    private String name;
    @ExcelProperty("保密编号")
    private String baomiNo;
    @ExcelProperty("资金来源")
    private String fundSrc;
    @ExcelProperty("联网类别")
    private String netType;
    @ExcelProperty("信息点号")
    private String portNo;
    @ExcelProperty("主机名称")
    private String hostName;
    @ExcelProperty("所在位置")
    private String location;
    @ExcelProperty("是否合用")
    private String shared;
    @ExcelProperty("合用人")
    private String nameShared;
    @ExcelProperty("状态")
    private String state;
    @ExcelProperty("用途")
    private String usagee;
    @ExcelProperty("使用人")
    private String administrator;
    @ExcelProperty("使用人电话")
    private String adminTel;
    @ExcelProperty("责任人")
    private String userName;
    @ExcelProperty("责任部门")
    private String userDept;
    @ExcelProperty("责任人密级")
    private String userMiji;
    @ExcelProperty("责任人电话")
    private String userTel;
    @ExcelProperty("设备厂商")
    private String manufacturer;
    @ExcelProperty("设备型号")
    private String model;
    @ExcelProperty("设备序列号")
    private String sn;
    @ExcelProperty("生产日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String madeDateTmp;
    @ExcelIgnore
    private LocalDate madeDate;
    @ExcelProperty("购买日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String buyDateTmp;
    @ExcelIgnore
    private LocalDate buyDate;
    @ExcelProperty("启用日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String useDateTmp;
    @ExcelIgnore
    private LocalDate useDate;
    @ExcelProperty("数量")
    private Integer price;
    @ExcelProperty("报废日期")
    @DateTimeFormat("yyyy-MM-dd")
    private String discardDateTmp;
    @ExcelIgnore
    private LocalDate discardDate;
    @ExcelProperty("IP地址")
    private String ip;
    @ExcelProperty("MAC地址")
    private String mac;
    @ExcelProperty("涉密级别")
    private String miji;
    @ExcelProperty("备注")
    private String remark;
    //AsSecurityProductsSpecial
    @ExcelProperty("检测证书名称")
    @ColumnWidth(20)
    private String certificateName;
    @ExcelProperty("检测证书编号")
    @ColumnWidth(20)
    private String certificateSn;
    @ExcelProperty("证书有效期")
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    @ColumnWidth(20)
    private String certificateDatetimeTmp;
    private LocalDateTime certificateDatetime;
    @ExcelProperty("策略")
    private String strategy;
}
