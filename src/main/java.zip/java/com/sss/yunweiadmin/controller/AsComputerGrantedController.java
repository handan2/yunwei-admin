package com.sss.yunweiadmin.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author 任勇林
 * @since 2021-04-14
 */
@RestController
@RequestMapping("/asComputerGranted")
public class AsComputerGrantedController {

}
