package com.sss.yunweiadmin.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;

import com.sss.yunweiadmin.common.config.GlobalParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 角色-菜单
 * </p>
 *
 * @author 任勇林
 * @since 2021-08-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class SysRoleMenu implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 对应sys_role表的id
     */
    private Integer roleId;

    /**
     * 对应sys_menu表的id
     */
    private Integer menuId;

    private Integer orgId = GlobalParam.orgId;
}
