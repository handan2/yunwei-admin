package com.sss.yunweiadmin.model.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.sss.yunweiadmin.common.config.GlobalParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author 任勇林
 * @since 2021-10-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class AsSecurityProductsSpecial implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private Integer asId;

    private String certificateName;

    private String certificateSn;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate certificateDate;

    private String strategy;

    private Integer orgId = GlobalParam.orgId;
}
